#!/usr/bin/env bash
# Requires GitHub CLI: https://cli.github.com  (run `gh auth login` first, then run inside the repo)
set -e
mk() { gh label create "$1" --color "$2" --description "$3" --force; }
# Type
mk "type: data"      "0E8A16" "Data collection, cleaning, access"
mk "type: analysis"  "1D76DB" "Exploration, stats, modelling"
mk "type: viz"       "5319E7" "Maps, charts, dashboard, UI"
mk "type: research"  "FBCA04" "Background, context, external datasets"
mk "type: pitch"     "D93F0B" "Slides, demo, storytelling"
mk "type: infra"     "BFD4F2" "Repo, environment, tooling"
# Priority
mk "prio: must"      "B60205" "Needed for MVP / demo"
mk "prio: should"    "FF9F1C" "Important but not blocking"
mk "prio: nice"      "C2E0C6" "Only if time allows"
# Dataset
mk "ds: heat-island" "F9D0C4" "Summerschool Heat-Islands 2026"
mk "ds: bike"        "C5DEF5" "senseBox:bike"
mk "ds: home"        "BFE5BF" "senseBox:home"
mk "ds: external"    "E4E669" "Other Heilbronn datasets"
# Status helpers
mk "blocked"         "000000" "Waiting on something/someone"
mk "ask-mentor"      "D4C5F9" "Needs mentor input"
