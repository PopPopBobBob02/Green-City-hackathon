# Datasets

Raw files are **not committed** (size). Put them in `data/raw/` locally; put cleaned, small outputs in `data/processed/`.
Fill in the table as you find the access links in the hackathon materials / on hackathon.greencity.hn.

| Dataset | What it contains | Measures | Access link | Owner | Status |
|---|---|---|---|---|---|
| Heat-Island Summerschool 2026 | Logged walks by students (11–16 y) across Heilbronn, Aug 2026 (~73 km, ~61.5k data points, 9 devices) | Temperature, humidity | _add link_ | _name_ | ☐ downloaded ☐ cleaned |
| senseBox:bike | Rides on Heilbronn bike lanes since Dec 2025 (~2,263 rides, 31 riders, ~5,200 km) | PM (fine dust), temperature, humidity, street surface type, overtaking likelihood & distance, GPS tracks | _add link (data guide / map)_ | _name_ | ☐ downloaded ☐ cleaned |
| senseBox:home | Stationary stations at ~15 schools and residents, 24/7 | Temperature, humidity, air pressure, PM | _add link_ | _name_ | ☐ downloaded ☐ cleaned |
| External Heilbronn data | e.g. city open data, tree cadastre, land use, noise maps, weather (DWD) | _fill in_ | _add link_ | _name_ | ☐ downloaded ☐ cleaned |

## Per-dataset notes
Add a short section per dataset: columns, units, time range, known quirks (missing values, sensor errors, GPS jumps), and licence.

### Heat-Island Summerschool 2026
- 

### senseBox:bike
- 

### senseBox:home
- 

### External datasets
- 

## Conventions
- Timestamps in UTC → convert to Europe/Berlin for display.
- Coordinates in WGS84 (EPSG:4326).
- Cleaned files: `data/processed/<dataset>_clean.csv` + one line here on what was cleaned.
