# Pitch outline (match to judging criteria)
1. **Problem** – real people, real problem in Heilbronn (Impact)
2. **Data** – what we used and why it's trustworthy enough (Technical execution)
3. **Solution / demo** – live walkthrough (Functionality, UX & design)
4. **What's new** – our angle (Innovation & originality)
5. **Impact & feasibility** – who uses it, what happens next, link to Green Capital 2027
6. **Team** – who did what (Teamwork)

Demo checklist: ☐ works offline/backup screenshots ☐ one clear takeaway ☐ timed run-through ☐ everyone speaks
