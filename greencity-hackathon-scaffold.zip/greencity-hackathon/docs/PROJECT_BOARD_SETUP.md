# GitHub Projects board – setup (≈10 min)

## 1. Create the repo (one person)
1. github.com → **New repository** → name `greencity-hackathon` → **Private** (or public if you want to share the result) → don't add a README (we have one).
2. Locally, in the unzipped folder:
   ```bash
   git init -b main
   git add . && git commit -m "Initial scaffold"
   git remote add origin https://github.com/<user-or-org>/greencity-hackathon.git
   git push -u origin main
   ```
3. **Settings → Collaborators** → add every teammate (Write access).
   Tip: for 4–6 people, a free **GitHub Organization** isn't needed; a personal repo with collaborators works fine.

## 2. Create labels
```bash
./scripts/create_labels.sh
```
(or create them manually from the file – 15 labels: type / prio / dataset / blocked / ask-mentor).

## 3. Create milestones
Repo → **Issues → Milestones → New**:
- `Tue 27 Oct – Setup & idea` (due 27 Oct)
- `Wed 28 Oct – Build` (due 28 Oct)
- `Thu 29 Oct – Polish & pitch` (due 29 Oct)

## 4. Create the Project board
1. Repo → **Projects → New project → Board** (name: `Hackathon Board`).
2. Rename the **Status** field's columns to:
   `📥 Backlog` · `🔜 Ready` · `🚧 In progress` · `👀 In review` · `✅ Done`
3. **Add custom fields** (＋ in the table view):
   - **Owner** → use the built-in *Assignees*
   - **Dataset** → single select: Heat-Island, Bike, Home, External, None
   - **Priority** → single select: Must, Should, Nice
   - **Size** → single select: S (<1h), M (half day), L (day+)
4. **Create views** (top tabs → New view):
   - **Board** – grouped by Status (default)
   - **By person** – Table, group by Assignees
   - **By dataset** – Table, group by Dataset
   - **Timeline** – Roadmap, uses milestones/dates
5. **Automation** (⋯ → Workflows): enable "Item closed → Done" and "Pull request merged → Done"; set "Item added → Backlog".
6. Project **Settings → Manage access** → add teammates. In the repo, **Projects → Link a project** so it appears in the repo tab.

## 5. Seed the backlog (copy these as issues)
**Tue – Setup & idea**
- Confirm idea with a mentor & register team on hackathon.greencity.hn `type: infra` `prio: must`
- Everyone joins Mattermost (chat.greencity.hn) `type: infra`
- Everyone clones repo & runs setup `type: infra` `prio: must`
- Download Heat-Island Summerschool data → `data/raw` `ds: heat-island` `type: data`
- Download senseBox:bike data `ds: bike` `type: data`
- Download senseBox:home data `ds: home` `type: data`
- Find & list 2–3 external Heilbronn datasets `ds: external` `type: research`
- Write problem statement + key questions in docs/PLAN.md `prio: must`
- Assign roles in docs/PLAN.md `prio: must`

**Wed – Build**
- Clean & document each dataset (one issue per dataset) `type: data`
- Exploratory analysis per dataset `type: analysis`
- Join datasets spatially/temporally (common grid/time bins) `type: analysis`
- Build first map/visual `type: viz`
- Draft MVP app/dashboard (e.g. Streamlit) `type: viz` `prio: must`
- Write impact argument linked to Green Capital topic `type: research`

**Thu – Polish & pitch**
- Freeze features (code freeze at agreed time) `prio: must`
- Fill docs/PITCH.md & build slides `type: pitch`
- Demo rehearsal ×2 + backup screenshots `type: pitch` `prio: must`
- Final README update & clean repo `type: infra`

## 6. Daily rhythm (5 min)
Stand-up at the board: what's In progress, what's blocked, what moves to Done. Update `docs/DECISIONS.md` for anything that changed scope.
