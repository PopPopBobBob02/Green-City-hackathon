# Project Plan

## 1. Problem statement
_One sentence: what problem in Heilbronn are we tackling and for whom?_

## 2. Green Capital topic(s)
☐ Waste & circular economy ☐ Water ☐ Noise ☐ Air quality ☐ Biodiversity & land use ☐ Climate mitigation ☐ Climate adaptation

## 3. Key question(s)
- e.g. Which streets get the hottest in summer, and where would trees help most?

## 4. Datasets we will use
(see data/README.md)

## 5. Deliverable
☐ Map ☐ Dashboard ☐ App ☐ Website ☐ Infographic ☐ Analysis ☐ Other: ___

## 6. Roles (4–6 people)
| Person | Main role | Backup |
|---|---|---|
| | Data wrangling | |
| | Analysis / modelling | |
| | Visualisation / app | |
| | Domain research & impact | |
| | Pitch & demo | |

## 7. Timeline
| When | Goal |
|---|---|
| **Tue 27 Oct** | 13:00 pitch/team formation → confirm idea with a mentor → register team on website → explore data, define approach, set up repo & board |
| **Wed 28 Oct** | Full build day: cleaning, analysis, prototype. Evening: freeze scope, start demo |
| **Thu 29 Oct** | Polish, rehearse pitch, finalist selection, jury presentation |

## 8. MVP vs. nice-to-have
- **MVP (must work for the demo):**
- **Nice-to-have:**

## 9. Risks
- 
