# Decisions log
| Date | Decision | Why | Who |
|---|---|---|---|
| 27 Oct | Python/notebooks stack, repo on GitHub | Team skill set | all |
