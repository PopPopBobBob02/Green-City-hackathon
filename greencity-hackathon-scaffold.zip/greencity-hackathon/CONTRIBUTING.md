# How we work

1. **Every task is an Issue** on the board. Assign yourself before starting.
2. **Branch per task:** `git switch -c <name>/<short-topic>` (e.g. `pop/bike-cleaning`).
3. **Small, frequent commits.** Pull before you push: `git pull --rebase origin main`.
4. **Open a Pull Request** into `main`, link the issue (`Closes #12`), ask one teammate to review. During the hackathon, quick review beats perfect review.
5. **Notebooks:** name them `NN_owner_topic.ipynb`. One person edits a notebook at a time – two people editing the same one causes painful merge conflicts. Reusable code goes in `src/`.
6. **Never commit** large raw data, API keys, or personal data. Use `data/raw/` (gitignored) and `.env`.
7. **Log decisions** in `docs/DECISIONS.md` (one line is enough).
8. Stuck for >20 min? Ask a mentor or post in Mattermost.
