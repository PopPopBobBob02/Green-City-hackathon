# Green City Heilbronn Hackathon – Team Workspace

> Data for the Heilbronn of tomorrow. · 27–29 Oct 2026 · OpenSpace Heilbronn

**Team name:** _TBD_
**Chosen topic(s):** _TBD (see docs/PLAN.md)_
**Team size:** 4–6 · **Stack:** Python / Jupyter notebooks

## Quick links
| What | Where |
|---|---|
| Plan, scope & timeline | [docs/PLAN.md](docs/PLAN.md) |
| Datasets & how to get them | [data/README.md](data/README.md) |
| Task board | GitHub **Projects** tab (see [docs/PROJECT_BOARD_SETUP.md](docs/PROJECT_BOARD_SETUP.md)) |
| Decisions log | [docs/DECISIONS.md](docs/DECISIONS.md) |
| Pitch outline | [docs/PITCH.md](docs/PITCH.md) |
| Hackathon chat | chat.greencity.hn (Mattermost) |
| Hackathon site / team registration | hackathon.greencity.hn |

## Repo layout
```
data/raw/        original downloads (NOT committed – see data/README.md)
data/processed/  cleaned/merged data (small files only)
notebooks/       exploration + analysis (name: NN_owner_topic.ipynb)
src/             reusable Python code (loaders, cleaning, plotting)
docs/            plan, decisions, pitch, board setup
scripts/         helper scripts (labels, data download)
```

## Setup
```bash
git clone <repo-url> && cd greencity-hackathon
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
nbstripout --install          # keeps notebook outputs out of git diffs
```

## Judging criteria (keep in mind)
Teamwork · Innovation & originality · Functionality & technical execution · Impact & feasibility · UX & design · Presentation & demo

See [CONTRIBUTING.md](CONTRIBUTING.md) for how we work together.
